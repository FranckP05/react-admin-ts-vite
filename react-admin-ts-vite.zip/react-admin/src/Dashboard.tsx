import { useEffect, useState } from "react";
import { Card, CardContent, Typography, Box } from "@mui/material";
import {
    BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
    PieChart, Pie, Cell, Legend
} from "recharts";
import { useDataProvider } from "react-admin";

interface PostCount {
    userId: string;
    username: string;
    posts: number;
}

interface PostDistribution {
    name: string;
    value: number;
}

const COLORS = ["#2e4052", "#ffc857"];

const Dashboard = () => {
    const dataProvider = useDataProvider();
    const [barChartData, setBarChartData] = useState<PostCount[]>([]);
    const [pieChartData, setPieChartData] = useState<PostDistribution[]>([]);

    useEffect(() => {
        // Fetch users & posts
        Promise.all([
            dataProvider.getList("users", { pagination: { page: 1, perPage: 100 } }),
            dataProvider.getList("posts", { pagination: { page: 1, perPage: 100 } })
        ])
            .then(([usersRes, postsRes]) => {
                const users = usersRes.data;
                const posts = postsRes.data;

                // Map userId -> userName
                const userMap: Record<string, string> = {};
                users.forEach((user: any) => {
                    userMap[user.id] = user.name;
                });

                // Count posts per user
                const counts: Record<string, number> = {};
                posts.forEach((post: any) => {
                    counts[post.userId] = (counts[post.userId] || 0) + 1;
                });

                // Prepare data for Bar Chart
                const formattedBarData = Object.entries(counts).map(([userId, count]) => ({
                    userId,
                    username: userMap[userId] || `User ${userId}`,
                    posts: count as number,
                }));
                setBarChartData(formattedBarData);

                // Prepare data for Pie Chart
                const publishedCount = posts.filter((p: any) => p.published).length;
                const draftCount = posts.length - publishedCount;
                setPieChartData([
                    { name: "Published", value: publishedCount },
                    { name: "Draft", value: draftCount },
                ]);
            })
            .catch(err => console.error("Error fetching data:", err));
    }, [dataProvider]);

    return (
        <Box sx={{ p: 2 }}>
            {/* Vertical Bar Chart */}
            <Card sx={{ mb: 3, p: 2 }}>
                <CardContent>
                    <Typography variant="h6" gutterBottom>
                        Number of Posts per User
                    </Typography>
                    <ResponsiveContainer width="100%" height={400}>
                        <BarChart
                            data={barChartData}
                            layout="vertical"
                            margin={{ top: 20, right: 20, bottom: 20, left: 120 }}
                        >
                            <YAxis
                                type="category"
                                dataKey="username"
                                width={120}
                                interval={0}
                                tick={{ fill: "#FFF", fontSize: 13 }}
                            />
                            <XAxis type="number" tick={{ fill: "#FFF", fontSize: 14 }} />
                            <Tooltip />
                            <Bar
                                dataKey="posts"
                                fill="#2e4052"
                                barSize={20}
                                radius={[0, 5, 5, 0]}
                            />
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* Pie Chart */}
            <Card sx={{ p: 2 }}>
                <CardContent>
                    <Typography variant="h6" gutterBottom>
                        Post Distribution (Published vs Drafts)
                    </Typography>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie
                                data={pieChartData}
                                dataKey="value"
                                nameKey="name"
                                cx="50%"
                                cy="50%"
                                outerRadius={80}
                                label
                            >
                                {pieChartData.map((entry, index) => (
                                    <Cell
                                        key={`cell-${index}`}
                                        fill={COLORS[index % COLORS.length]}
                                    />
                                ))}
                            </Pie>
                            <Tooltip />
                            <Legend
                                verticalAlign="bottom"
                                align="center"
                                iconType="circle"
                                wrapperStyle={{ color: "#FFF", fontSize: 14 }}
                            />

                        </PieChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>
        </Box>
    );
};

export default Dashboard;
