// src/UsersList.tsx
import React from "react";
import {
    List,
    Datagrid,
    TextField,
    EditButton,
    BulkDeleteButton,
    useNotify,
    useRefresh,
    useRecordContext,
    useListContext,
    useDataProvider
} from "react-admin";
import { Button, Box } from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";

// Custom Active Status Column with Label
const ActiveStatusField = () => {
    const record = useRecordContext();
    if (!record) return null;
    return (
        <Box sx={{ display: "flex", alignItems: "center" }}>
            {record.active ? (
                <CheckCircleIcon sx={{ color: "#2e4052" }} />
            ) : (
                <CancelIcon sx={{ color: "#ffc857" }} />
            )}
        </Box>
    );
};
ActiveStatusField.defaultProps = { label: "Active" };

// Bulk Action Buttons Component
const UserBulkActionButtons = () => {
    const { selectedIds } = useListContext();
    const dataProvider = useDataProvider();
    const notify = useNotify();
    const refresh = useRefresh();

    const handleBulkActivate = async () => {
        try {
            const users = await dataProvider.getMany("users", { ids: selectedIds });
            await dataProvider.updateMany("users", {
                ids: selectedIds,
                data: users.data.map(user => ({ ...user, active: true })), // Preserve all fields
            });
            notify("Users activated successfully", { type: "success" });
            refresh();
        } catch (error) {
            console.error("Error activating users:", error);
            notify("Error activating users", { type: "error" });
        }
    };
    
    const handleBulkDeactivate = async () => {
        try {
            const users = await dataProvider.getMany("users", { ids: selectedIds });
            await dataProvider.updateMany("users", {
                ids: selectedIds,
                data: users.data.map(user => ({ ...user, active: false })), 
            });
            notify("Users deactivated successfully", { type: "success" });
            refresh();
        } catch (error) {
            console.error("Error deactivating users:", error);
            notify("Error deactivating users", { type: "error" });
        }
    };

    return (
        <Box sx={{ display: "flex", gap: 1, p: 1 }}>
            <Button
                onClick={handleBulkActivate}
                startIcon={<ToggleOnIcon />}
                variant="contained"
                color="success"
                disabled={selectedIds.length === 0}
            >
                Activate
            </Button>
            <Button
                onClick={handleBulkDeactivate}
                startIcon={<ToggleOffIcon />}
                variant="contained"
                color="error"
                disabled={selectedIds.length === 0}
            >
                Deactivate
            </Button>
            <BulkDeleteButton />
        </Box>
    );
};

import { useTheme } from "@mui/material/styles"; // ✅ Importer le thème

const UsersList = () => {
    const theme = useTheme(); // ✅ Récupérer le mode (light/dark)

    return (
        <List title="Users">
            <Datagrid
                rowClick="edit"
                bulkActionButtons={<UserBulkActionButtons />}
                sx={{
                    backgroundColor: theme.palette.mode === "dark" ? "#04151f" : "#e8e8e4", 
                    color: theme.palette.mode === "dark" ? "#8e8e4" : "#04151f",
                    "& .RaDatagrid-row:hover": {
                        backgroundColor: theme.palette.mode === "dark" ? "#04151f" : "#e8e8e4", 
                    },
                }}
            >
                <TextField source="id" sx={{ width: "80px", minWidth: "80px" }} />
                <TextField source="name" sx={{ flex: 2, minWidth: "300px" }} />
                <TextField source="email" sx={{ flex: 3, minWidth: "500px" }} />
                <ActiveStatusField label="Active" />
                <EditButton />
            </Datagrid>
        </List>
    );
};


export default UsersList;
