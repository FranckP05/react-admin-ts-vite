// src/CustomAppBar.tsx
import { Admin, AppBar, TitlePortal, useResourceContext } from "react-admin";
import { Box, Typography, IconButton } from "@mui/material";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import { useTheme } from "@mui/material/styles";
import PeopleIcon from "@mui/icons-material/People";
import ArticleIcon from "@mui/icons-material/Article";
import DashboardIcon from "@mui/icons-material/Dashboard";
import { useLocation } from "react-router-dom";

const CustomAppBar = (props: any) => {
    const theme = useTheme();
    const isDarkMode = theme.palette.mode === "dark";

    const toggleTheme = () => {
        const newTheme = isDarkMode ? "light" : "dark";
        localStorage.setItem("theme", newTheme);
        window.location.reload();
    };

    const resource = useResourceContext();
    

const getIcon = () => {
    const location = useLocation();

    if (location.pathname === "/") {
        return <><DashboardIcon sx={{ fontSize: 24, mr: 1 }} /> Dashboard</>;
    }
    if (resource === "users") {
        return <><PeopleIcon sx={{ fontSize: 24, mr: 1 }} /> Users</>;
    }
    if (resource === "posts") {
        return <><ArticleIcon sx={{ fontSize: 24, mr: 1 }} /> Posts</>;
    }
    return <><DashboardIcon sx={{ fontSize: 24, mr: 1 }} />  </>;
};

    

    return (
        <AppBar {...props} sx={{ backgroundColor: "#2d3142", color: "#ffffff", display: "flex", paddingX: 2 }}>
            {/* Admin Panel Label with proper spacing */}
            <Typography variant="h6" sx={{ mr: 3 }}>
                Admin Panel
            </Typography>

            {/* Centered Title with Icon */}
            <Box sx={{ flex: 1, display: "flex", justifyContent: "center", alignItems: "center" }}>
                {getIcon()}
                <Typography variant="h6" sx={{ ml: 1 }}>
                    <TitlePortal />
                </Typography>
            </Box>

            {/* Dark Mode Toggle */}
            <IconButton onClick={toggleTheme} color="inherit">
                {isDarkMode ? <Brightness7Icon /> : <Brightness4Icon />}
            </IconButton>
        </AppBar>
    );
};

export default CustomAppBar;
