// src/App.tsx
import { Admin, Resource } from "react-admin";
import jsonServerProvider from "ra-data-json-server";
import { ThemeProvider } from "@mui/material/styles";
import { useState, useEffect } from "react";
import { lightTheme, darkTheme } from "./theme";
import CustomLayout from "./CustomLayout";
import Dashboard from "./Dashboard";
import UserList from "./userList";
import UserEdit from "./userEdit";
import UserCreate from "./userCreate";
import UserShow from "./userShow";
import PostList from "./postList";
import PostEdit from "./postEdit";
import PostCreate from "./postCreate";
import PostShow from "./postShow";

const dataProvider = jsonServerProvider("/api");

const App = () => {
    const [isDarkMode, setIsDarkMode] = useState(
        localStorage.getItem("theme") === "dark"
    );

    useEffect(() => {
        localStorage.setItem("theme", isDarkMode ? "dark" : "light");
    }, [isDarkMode]);

    return (
        <ThemeProvider theme={isDarkMode ? darkTheme : lightTheme}>
            <Admin
                dataProvider={dataProvider}
                theme={isDarkMode ? darkTheme : lightTheme}
                layout={CustomLayout}
                dashboard={Dashboard} 
            >
                <Resource
                    name="users"
                    list={UserList}
                    edit={UserEdit}
                    create={UserCreate}
                    show={UserShow}
                />
                <Resource
                    name="posts"
                    list={PostList}
                    edit={PostEdit}
                    create={PostCreate}
                    show={PostShow}
                />
            </Admin>
            <button 
                style={{
                    position: "fixed", 
                    bottom: 20, 
                    right: 20, 
                    padding: "10px 15px",
                    backgroundColor: isDarkMode ? "#F2C94C" : "#254D77",
                    color: isDarkMode ? "#121212" : "#FFF",
                    border: "none",
                    borderRadius: "5px",
                    cursor: "pointer"
                }}
                onClick={() => setIsDarkMode(!isDarkMode)}
            >
                {isDarkMode ? "Light Mode" : "Dark Mode"}
            </button>
        </ThemeProvider>
    );
};

export default App;
