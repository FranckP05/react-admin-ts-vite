// src/PostEdit.tsx
import { Edit, SimpleForm, TextInput, BooleanInput } from "react-admin";

const PostEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" disabled fullWidth />
            <TextInput source="title" fullWidth />
            <TextInput source="author" fullWidth />
            <BooleanInput source="published" />
        </SimpleForm>
    </Edit>
);

export default PostEdit;
