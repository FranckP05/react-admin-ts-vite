// src/UserCreate.tsx
import { Create, SimpleForm, TextInput, BooleanInput } from "react-admin";

const UserCreate = () => (
    <Create>
        <SimpleForm>
            <TextInput source="name" fullWidth />
            <TextInput source="email" type="email" fullWidth />
            <BooleanInput source="active" />
        </SimpleForm>
    </Create>
);

export default UserCreate;
