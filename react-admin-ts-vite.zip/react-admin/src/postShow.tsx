// src/PostShow.tsx
import { Show, SimpleShowLayout, TextField, BooleanField } from "react-admin";

const PostShow = () => (
    <Show>
        <SimpleShowLayout>
            <TextField source="id" />
            <TextField source="title" />
            <TextField source="author" />
            <BooleanField source="published" />
        </SimpleShowLayout>
    </Show>
);

export default PostShow;
