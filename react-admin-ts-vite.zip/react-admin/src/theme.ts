import { createTheme } from '@mui/material/styles';

// Configuration de la police
const typography = {
    fontFamily: '"Sora", sans-serif',
};

// Palette de couleurs pour le dark theme
const darkTheme = createTheme({
    palette: {
        mode: 'dark',
        background: {
            default: '#121212',
            paper: '#1E1E1E',
        },
        text: {
            primary: '#E0E0E0',
            secondary: '#B0B0B0',
        },
        primary: {
            main: '#4A90E2', // Bleu vif
        },
        secondary: {
            main: '#F2C94C', // Jaune chaud
        },
    },
    typography,
});

// Palette de couleurs pour le light theme
const lightTheme = createTheme({
    palette: {
        mode: 'light',
        background: {
            default: '#FFFFFF',
            paper: '#F8F8F8',
        },
        text: {
            primary: '#060600',
            secondary: '#9999A0',
        },
        primary: {
            main: '#254D77',
        },
        secondary: {
            main: '#FFC857',
        },
    },
    typography,
});

export { darkTheme, lightTheme };
