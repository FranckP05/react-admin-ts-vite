import React from 'react';
import { BulkDeleteButton } from 'react-admin';
import BulkDeactivateButton from './BulkDeactivateButton';

const UserBulkActionButtons = () => (
    <>
        <BulkDeactivateButton />
        <BulkDeleteButton />
    </>
);

export default UserBulkActionButtons;
