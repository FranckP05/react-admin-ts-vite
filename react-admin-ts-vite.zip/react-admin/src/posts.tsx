import { List, Datagrid, TextField, ReferenceField } from 'react-admin';

export const PostList = () => (
  <List>
    <Datagrid>
      <TextField source="id" />
      <TextField source="title" label="Titre" />
      <ReferenceField source="userId" reference="users">
        <TextField source="name" label="Auteur" />
      </ReferenceField>
    </Datagrid>
  </List>
);
