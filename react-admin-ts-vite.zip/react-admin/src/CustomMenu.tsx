// src/CustomMenu.tsx
import { Menu } from "react-admin";
import { Box } from "@mui/material";

const CustomMenu = (props: any) => {
    return (
        <Box sx={{ backgroundColor: "#2d3142", height: "100vh", color: "#ffffff" }}>
            <Menu {...props} />
        </Box>
    );
};

export default CustomMenu;
