// src/PublishedPieChart.tsx
import { useEffect, useState } from "react";
import { Card, CardContent, Typography } from "@mui/material";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { useDataProvider } from "react-admin";

// Définition du type des données du graphique
interface PostDistribution {
    name: string;
    value: number;
}

const COLORS = ["#2e4052", "#ffc857"]; // Couleurs pour les segments

const PublishedPieChart = () => {
    const dataProvider = useDataProvider();
    const [chartData, setChartData] = useState<PostDistribution[]>([]);

    useEffect(() => {
        // Récupérer tous les posts
        dataProvider.getList("posts", { pagination: { page: 1, perPage: 100 } })
            .then(({ data }) => {
                const publishedCount = data.filter((post: any) => post.published).length;
                const draftCount = data.length - publishedCount;

                setChartData([
                    { name: "Publiés", value: publishedCount },
                    { name: "Brouillons", value: draftCount }
                ]);
            })
            .catch(error => console.error("Error fetching posts:", error));
    }, [dataProvider]);

    return (
        <Card sx={{ m: 2, p: 2 }}>
            <CardContent>
                <Typography variant="h6" gutterBottom>
                    📝 Répartition des posts (Publiés vs Brouillons)
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie
                            data={chartData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={100}
                            label
                        >
                            {chartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
};

export default PublishedPieChart;
