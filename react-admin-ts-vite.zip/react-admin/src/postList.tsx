// src/PostList.tsx
import React from "react";
import {
    List,
    Datagrid,
    TextField,
    EditButton,
    ReferenceField,
    BulkDeleteButton,
    useNotify,
    useRefresh,
    useRecordContext,
    useListContext,
    useDataProvider
} from "react-admin";
import { useTheme } from "@mui/material/styles";
import { Button, Box } from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import PublishIcon from "@mui/icons-material/Publish";
import BlockIcon from "@mui/icons-material/Block";

// ✅ Composant pour afficher le statut de publication avec une icône
const PublishedStatus = () => {
    const record = useRecordContext();
    if (!record) return null;
    return record.published ? (
        <CheckCircleIcon sx={{ color: "#2e4052" }} />
    ) : (
        <CancelIcon sx={{ color: "#ffc857" }} />
    );
};

// ✅ Boutons d'actions groupées
const PostBulkActionButtons = () => {
    const { selectedIds } = useListContext();
    const dataProvider = useDataProvider();
    const notify = useNotify();
    const refresh = useRefresh();

    const handleBulkUpdate = async (published: boolean) => {
        try {
            await dataProvider.updateMany("posts", {
                ids: selectedIds,
                data: { published }
            });
            notify(published ? "Posts published successfully" : "Posts unpublished successfully", { type: "success" });
            refresh();
        } catch (error) {
            console.error("Error updating posts:", error);
            notify("Error updating posts", { type: "warning" });
        }
    };

    return (
        <Box sx={{ display: "flex", gap: 1, p: 1 }}>
            <Button
                onClick={() => handleBulkUpdate(true)}
                startIcon={<PublishIcon />}
                variant="contained"
                color="success"
                disabled={selectedIds.length === 0}
            >
                Publish
            </Button>
            <Button
                onClick={() => handleBulkUpdate(false)}
                startIcon={<BlockIcon />}
                variant="contained"
                color="error"
                disabled={selectedIds.length === 0}
            >
                Unpublish
            </Button>
            <BulkDeleteButton />
        </Box>
    );
};


const PostList = () => {
    const theme = useTheme(); 
    
    return (
        <List>
            <Datagrid
                rowClick="edit"
                bulkActionButtons={<PostBulkActionButtons />}
                sx={{
                    backgroundColor: theme.palette.mode === "dark" ? "#04151f" : "#e8e8e4", 
                    color: theme.palette.mode === "dark" ? "#e8e8e4" : "#04151f",
                    "& .RaDatagrid-row:hover": {
                        backgroundColor: theme.palette.mode === "dark" ? "#04151f" : "#e8e8e4",
                    },
                }}
            >
                <TextField source="id" label="ID" sx={{ width: "80px", minWidth: "80px" }} />
                <TextField source="title" label="Title" sx={{ flex: 1, minWidth: "250px" }} />
                <ReferenceField source="userId" reference="users" label="Author">
                    <TextField source="name" sx={{ minWidth: "150px" }} />
                </ReferenceField>
                <TextField source="published" label="Published" sx={{ display: "none" }} />
                <Box sx={{ width: "80px", minWidth: "80px", display: "flex", justifyContent: "center" }}>
                    <PublishedStatus />
                </Box>
                <EditButton />
            </Datagrid>
        </List>
    );
};




export default PostList;
