// src/UserEdit.tsx
import { Edit, SimpleForm, TextInput, BooleanInput } from "react-admin";

const UserEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" disabled fullWidth />
            <TextInput source="name" fullWidth />
            <TextInput source="email" type="email" fullWidth />
            <BooleanInput source="active" />
        </SimpleForm>
    </Edit>
);

export default UserEdit;
