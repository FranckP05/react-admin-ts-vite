// src/PostCreate.tsx
import { Create, SimpleForm, TextInput, BooleanInput } from "react-admin";

const PostCreate = () => (
    <Create>
        <SimpleForm>
            <TextInput source="title" fullWidth />
            <TextInput source="author" fullWidth />
            <BooleanInput source="published" />
        </SimpleForm>
    </Create>
);

export default PostCreate;
