import React from 'react';
import {
    useListContext,
    useDataProvider,
    useNotify,
    useRefresh,
    useUnselectAll,
} from 'react-admin';
import { Button } from '@mui/material';

const BulkDeactivateButton = () => {
    // Get the selected IDs from the list context:
    const { selectedIds } = useListContext();
    const dataProvider = useDataProvider();
    const notify = useNotify();
    const refresh = useRefresh();
    const unselectAll = useUnselectAll();

    const handleClick = async () => {
        if (!selectedIds || selectedIds.length === 0) return;
        if (!window.confirm('Are you sure you want to deactivate the selected users?')) {
            return;
        }
        try {
            await Promise.all(
                selectedIds.map((id: any) =>
                    dataProvider.update('users', {
                        id,
                        data: { active: false },
                        previousData: {},
                    })
                )
            );
            notify('Users deactivated successfully', { type: 'success' });
            refresh();
            unselectAll();
        } catch (error) {
            notify('Error deactivating users', { type: 'error' });
        }
    };

    return (
        <Button
            onClick={handleClick}
            disabled={!selectedIds || selectedIds.length === 0}
            variant="contained"
            color="secondary"
        >
            Deactivate Users
        </Button>
    );
};

export default BulkDeactivateButton;
