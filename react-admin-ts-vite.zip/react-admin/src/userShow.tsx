// src/UserShow.tsx
import { Show, SimpleShowLayout, TextField, BooleanField } from "react-admin";

const UserShow = () => (
    <Show>
        <SimpleShowLayout>
            <TextField source="id" />
            <TextField source="name" />
            <TextField source="email" />
            <BooleanField source="active" />
        </SimpleShowLayout>
    </Show>
);

export default UserShow;
